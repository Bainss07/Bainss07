﻿public class Player
{
    public int Id { get; set; }
    public string PlayerName { get; set; }
    public string TeamName { get; set; }
    public string Role { get; set; }
    public string BattingStyle { get; set; }
    public string BowlingStyle { get; set; }
    public DateTime DOB { get; set; }
    public string PhotoPath { get; set; }
}
