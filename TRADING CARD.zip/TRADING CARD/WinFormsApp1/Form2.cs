﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        // Event handler to save the player details to the database
        private void btnUploadPhoto_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Get the file extension from the selected photo
                string fileExtension = Path.GetExtension(openFileDialog.FileName).ToLower();

                string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                // Navigate to the root directory of the project
                string projectRootDirectory = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\.."));
                string imageFolderPath = Path.Combine(projectRootDirectory, "Images");

                // Construct the destination path using string interpolation
                string destinationPath = Path.Combine(imageFolderPath, $"{txtPlayerName.Text}{fileExtension}"); // Combine the folder path and file name
                // Copy the photo to the specified location
                try
                {
                    // Ensure that only supported image formats are copied
                    if (fileExtension == ".jpg" || fileExtension == ".jpeg" || fileExtension == ".png" || fileExtension == ".bmp")
                    {
                        File.Copy(openFileDialog.FileName, destinationPath);

                        // Optionally, show a confirmation message
                        MessageBox.Show($"Photo uploaded successfully. Saved to {destinationPath}");

                        // Show the image in a PictureBox (if available)
                        pictureBox.Image = Image.FromFile(destinationPath);
                    }
                    else
                    {
                        MessageBox.Show("Unsupported file type. Please upload a JPG, PNG, or BMP image.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error uploading the photo: " + ex.Message);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Get player details from the form fields
            string playerName = txtPlayerName.Text;
            string teamName = txtTeamName.Text;
            string role = txtRole.Text;
            string battingStyle = txtBattingStyle.Text;
            string bowlingStyle = txtBowlingStyle.Text;
            DateTime dob = dtpDOB.Value;

            // Get the extension of the uploaded image file
            string fileExtension = Path.GetExtension(openFileDialog.FileName).ToLower();


            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            // Navigate to the root directory of the project
            string projectRootDirectory = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\.."));
            string imageFolderPath = Path.Combine(projectRootDirectory, "Images");

            // Set the photo path automatically with the correct file extension
            string photoDirectory = imageFolderPath;

            string photoPath = Path.Combine(photoDirectory, playerName + fileExtension);

            
     
            // Check if the required fields are filled
            if (string.IsNullOrEmpty(playerName) || string.IsNullOrEmpty(teamName) ||
                string.IsNullOrEmpty(role) || string.IsNullOrEmpty(battingStyle) ||
                string.IsNullOrEmpty(bowlingStyle))
            {
                MessageBox.Show("Please fill all the fields.");
                return;
            }

            try
            {
                // Save the player details to the database
                using (var context = new PlayerContext())
                {
                    var player = new Player
                    {
                        PlayerName = playerName,
                        TeamName = teamName,
                        Role = role,
                        BattingStyle = battingStyle,
                        BowlingStyle = bowlingStyle,
                        DOB = dob,
                        PhotoPath = photoPath // Automatically set the photo path
                    };

                    context.Players.Add(player);
                    context.SaveChanges();
                }

                MessageBox.Show("Player details saved successfully!");

                // Optionally, save a default photo if you need it
                // You can add your logic here to save a default image in the specified directory

                // Close the form after saving
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
