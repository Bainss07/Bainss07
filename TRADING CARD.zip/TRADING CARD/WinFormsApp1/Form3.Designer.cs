﻿namespace WinFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPlayerName = new System.Windows.Forms.TextBox();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.txtBattingStyle = new System.Windows.Forms.TextBox();
            this.txtBowlingStyle = new System.Windows.Forms.TextBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.pictureBoxPlayer = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnChangePhoto = new System.Windows.Forms.Button();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblBattingStyle = new System.Windows.Forms.Label();
            this.lblBowlingStyle = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).BeginInit();
            this.SuspendLayout();

            // 
            // txtPlayerName
            // 
            this.txtPlayerName.Location = new System.Drawing.Point(160, 30);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(200, 20);
            this.txtPlayerName.TabIndex = 0;

            // 
            // lblPlayerName
            // 
            this.lblPlayerName.Location = new System.Drawing.Point(80, 30);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(80, 20);
            this.lblPlayerName.Text = "Player Name:";

            // 
            // txtTeamName
            // 
            this.txtTeamName.Location = new System.Drawing.Point(160, 60);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(200, 20);
            this.txtTeamName.TabIndex = 1;

            // 
            // lblTeamName
            // 
            this.lblTeamName.Location = new System.Drawing.Point(80, 60);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(80, 20);
            this.lblTeamName.Text = "Team Name:";

            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(160, 90);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(200, 20);
            this.txtRole.TabIndex = 2;

            // 
            // lblRole
            // 
            this.lblRole.Location = new System.Drawing.Point(80, 90);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(80, 20);
            this.lblRole.Text = "Role:";

            // 
            // txtBattingStyle
            // 
            this.txtBattingStyle.Location = new System.Drawing.Point(160, 120);
            this.txtBattingStyle.Name = "txtBattingStyle";
            this.txtBattingStyle.Size = new System.Drawing.Size(200, 20);
            this.txtBattingStyle.TabIndex = 3;

            // 
            // lblBattingStyle
            // 
            this.lblBattingStyle.Location = new System.Drawing.Point(80, 120);
            this.lblBattingStyle.Name = "lblBattingStyle";
            this.lblBattingStyle.Size = new System.Drawing.Size(80, 20);
            this.lblBattingStyle.Text = "Batting Style:";

            // 
            // txtBowlingStyle
            // 
            this.txtBowlingStyle.Location = new System.Drawing.Point(160, 150);
            this.txtBowlingStyle.Name = "txtBowlingStyle";
            this.txtBowlingStyle.Size = new System.Drawing.Size(200, 20);
            this.txtBowlingStyle.TabIndex = 4;

            // 
            // lblBowlingStyle
            // 
            this.lblBowlingStyle.Location = new System.Drawing.Point(80, 150);
            this.lblBowlingStyle.Name = "lblBowlingStyle";
            this.lblBowlingStyle.Size = new System.Drawing.Size(80, 20);
            this.lblBowlingStyle.Text = "Bowling Style:";

            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(160, 180);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 20);
            this.dtpDOB.TabIndex = 5;

            // 
            // lblDOB
            // 
            this.lblDOB.Location = new System.Drawing.Point(80, 180);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(80, 20);
            this.lblDOB.Text = "DOB:";

            // 
            // pictureBoxPlayer
            // 
            this.pictureBoxPlayer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxPlayer.Location = new System.Drawing.Point(400, 30);
            this.pictureBoxPlayer.Name = "pictureBoxPlayer";
            this.pictureBoxPlayer.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPlayer.TabIndex = 6;
            this.pictureBoxPlayer.TabStop = false;

            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(160, 220);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save Changes";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // 
            // btnChangePhoto
            // 
            this.btnChangePhoto.Location = new System.Drawing.Point(400, 240);
            this.btnChangePhoto.Name = "btnChangePhoto";
            this.btnChangePhoto.Size = new System.Drawing.Size(100, 30);
            this.btnChangePhoto.TabIndex = 8;
            this.btnChangePhoto.Text = "Change Photo";
            this.btnChangePhoto.UseVisualStyleBackColor = true;
            this.btnChangePhoto.Click += new System.EventHandler(this.btnChangePhoto_Click);

            // 
            // Form3
            // 
            this.ClientSize = new System.Drawing.Size(650, 300);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblBowlingStyle);
            this.Controls.Add(this.lblBattingStyle);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.lblTeamName);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.btnChangePhoto);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.pictureBoxPlayer);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.txtBowlingStyle);
            this.Controls.Add(this.txtBattingStyle);
            this.Controls.Add(this.txtRole);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.txtPlayerName);
            this.Name = "Form3";
            this.Text = "Modify Player Details";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtPlayerName;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.TextBox txtBattingStyle;
        private System.Windows.Forms.TextBox txtBowlingStyle;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.PictureBox pictureBoxPlayer;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnChangePhoto;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblBattingStyle;
        private System.Windows.Forms.Label lblBowlingStyle;
        private System.Windows.Forms.Label lblDOB;
    }
}
