﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            button1 = new Button();
            splitContainer1 = new SplitContainer();
            flowLayoutPanel1 = new FlowLayoutPanel();
            panelBottom = new Panel();
            buttonAddPlayer = new Button();
            buttonCloseApp = new Button();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.SuspendLayout();
            panelBottom.SuspendLayout();
            SuspendLayout();

            // 
            // button1
            // 
            button1.Location = new Point(82, 81);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;

            // 
            // splitContainer1
            // 
            splitContainer1.Location = new Point(6, 7);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Panel1.Controls.Add(flowLayoutPanel1);
            splitContainer1.Size = new Size(1200, 687);
            splitContainer1.SplitterDistance = 300;
            splitContainer1.TabIndex = 1;

            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.Dock = DockStyle.Fill;
            flowLayoutPanel1.Location = new Point(0, 0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(300, 687);
            flowLayoutPanel1.TabIndex = 0;

            // 
            // panelBottom
            // 
            panelBottom.Controls.Add(buttonAddPlayer);
            panelBottom.Controls.Add(buttonCloseApp);
            panelBottom.Dock = DockStyle.Bottom;
            panelBottom.Location = new Point(0, 700);
            panelBottom.Name = "panelBottom";
            panelBottom.Size = new Size(1200, 100);
            panelBottom.TabIndex = 2;

            // 
            // buttonAddPlayer
            // 
            buttonAddPlayer.Location = new Point(355, 25);
            buttonAddPlayer.Name = "buttonAddPlayer";
            buttonAddPlayer.Size = new Size(200, 40);
            buttonAddPlayer.TabIndex = 0;
            buttonAddPlayer.Text = "Add Player";
            buttonAddPlayer.UseVisualStyleBackColor = false;
            buttonAddPlayer.BackColor = Color.Blue; // Button background color
            buttonAddPlayer.ForeColor = Color.White; // Text color
            buttonAddPlayer.Font = new Font("Arial", 12, FontStyle.Bold); // Font styling
            buttonAddPlayer.FlatStyle = FlatStyle.Flat;
            buttonAddPlayer.FlatAppearance.BorderSize = 0; // Remove border
            buttonAddPlayer.Click += ButtonAddPlayer_Click;
            buttonAddPlayer.MouseEnter += Button_MouseEnter; // Hover effect
            buttonAddPlayer.MouseLeave += Button_MouseLeave; // Reset hover effect

            // 
            // buttonCloseApp
            // 
            buttonCloseApp.Location = new Point(634, 25);
            buttonCloseApp.Name = "buttonCloseApp";
            buttonCloseApp.Size = new Size(200, 40);
            buttonCloseApp.TabIndex = 1;
            buttonCloseApp.Text = "Close Application";
            buttonCloseApp.UseVisualStyleBackColor = false;
            buttonCloseApp.BackColor = Color.Firebrick; // Button background color
            buttonCloseApp.ForeColor = Color.White; // Text color
            buttonCloseApp.Font = new Font("Arial", 12, FontStyle.Bold); // Font styling
            buttonCloseApp.FlatStyle = FlatStyle.Flat;
            buttonCloseApp.FlatAppearance.BorderSize = 0; // Remove border
            buttonCloseApp.Click += ButtonCloseApp_Click;
            buttonCloseApp.MouseEnter += Button_MouseEnter; // Hover effect
            buttonCloseApp.MouseLeave += Button_MouseLeave; // Reset hover effect

            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 800);
            Controls.Add(splitContainer1);
            Controls.Add(panelBottom);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panelBottom.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Button buttonAddPlayer;
        private System.Windows.Forms.Button buttonCloseApp;

        private void ButtonAddPlayer_Click(object sender, EventArgs e)
        {
            Form2 addPlayerForm = new Form2();
            addPlayerForm.ShowDialog(); // Open the form as a modal dialog
            LoadPlayerNames(); // Refresh the list of players after adding a new player
        }

        // Event handler for "Close Application" button click
        private void ButtonCloseApp_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the application
        }

        // Hover effect: Change background color on mouse enter
        private void Button_MouseEnter(object sender, EventArgs e)
        {
            Button button = sender as Button;
            button.BackColor = Color.MidnightBlue; // Change to a darker shade on hover
        }

        // Reset hover effect: Change background color back to original on mouse leave
        private void Button_MouseLeave(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button == buttonAddPlayer)
                button.BackColor = Color.Blue;
            else if (button == buttonCloseApp)
                button.BackColor = Color.Firebrick;
        }
    }
}
