﻿namespace WinFormsApp1

{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox pictureBox;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox = new System.Windows.Forms.PictureBox();

            // Set the properties for the PictureBox
            this.pictureBox.Location = new System.Drawing.Point(130, 350); // Position on the form
            this.pictureBox.Name = "pictureBox"; // Name of the control
            this.pictureBox.Size = new System.Drawing.Size(00, 00); // Size of the PictureBox
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage; // To stretch the image to fit the box
            this.Controls.Add(this.pictureBox); // Add the PictureBox to the form


            this.txtPlayerName = new System.Windows.Forms.TextBox();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.txtBattingStyle = new System.Windows.Forms.TextBox();
            this.txtBowlingStyle = new System.Windows.Forms.TextBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblBattingStyle = new System.Windows.Forms.Label();
            this.lblBowlingStyle = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.btnUploadPhoto = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();

            this.SuspendLayout();

            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Location = new System.Drawing.Point(20, 30);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(110, 20);
            this.lblPlayerName.TabIndex = 0;
            this.lblPlayerName.Text = "Player Name:";

            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(20, 70);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(96, 20);
            this.lblTeamName.TabIndex = 1;
            this.lblTeamName.Text = "Team Name:";

            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(20, 110);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(42, 20);
            this.lblRole.TabIndex = 2;
            this.lblRole.Text = "Role:";

            // 
            // lblBattingStyle
            // 
            this.lblBattingStyle.AutoSize = true;
            this.lblBattingStyle.Location = new System.Drawing.Point(20, 150);
            this.lblBattingStyle.Name = "lblBattingStyle";
            this.lblBattingStyle.Size = new System.Drawing.Size(97, 20);
            this.lblBattingStyle.TabIndex = 3;
            this.lblBattingStyle.Text = "Batting Style:";

            // 
            // lblBowlingStyle
            // 
            this.lblBowlingStyle.AutoSize = true;
            this.lblBowlingStyle.Location = new System.Drawing.Point(20, 190);
            this.lblBowlingStyle.Name = "lblBowlingStyle";
            this.lblBowlingStyle.Size = new System.Drawing.Size(100, 20);
            this.lblBowlingStyle.TabIndex = 4;
            this.lblBowlingStyle.Text = "Bowling Style:";

            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(20, 230);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(44, 20);
            this.lblDOB.TabIndex = 5;
            this.lblDOB.Text = "DOB:";

            // 
            // txtPlayerName
            // 
            this.txtPlayerName.Location = new System.Drawing.Point(130, 30);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(200, 25);
            this.txtPlayerName.TabIndex = 7;

            // 
            // txtTeamName
            // 
            this.txtTeamName.Location = new System.Drawing.Point(130, 70);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(200, 25);
            this.txtTeamName.TabIndex = 8;

            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(130, 110);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(200, 25);
            this.txtRole.TabIndex = 9;

            // 
            // txtBattingStyle
            // 
            this.txtBattingStyle.Location = new System.Drawing.Point(130, 150);
            this.txtBattingStyle.Name = "txtBattingStyle";
            this.txtBattingStyle.Size = new System.Drawing.Size(200, 25);
            this.txtBattingStyle.TabIndex = 10;

            // 
            // txtBowlingStyle
            // 
            this.txtBowlingStyle.Location = new System.Drawing.Point(130, 190);
            this.txtBowlingStyle.Name = "txtBowlingStyle";
            this.txtBowlingStyle.Size = new System.Drawing.Size(200, 25);
            this.txtBowlingStyle.TabIndex = 11;

            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(130, 230);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 25);
            this.dtpDOB.TabIndex = 12;

            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(130, 350);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(200, 40);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Save Player";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // 
            // btnUploadPhoto
            // 
            this.btnUploadPhoto.Location = new System.Drawing.Point(130, 270);
            this.btnUploadPhoto.Name = "btnUploadPhoto";
            this.btnUploadPhoto.Size = new System.Drawing.Size(200, 30);
            this.btnUploadPhoto.TabIndex = 15;
            this.btnUploadPhoto.Text = "Upload Photo";
            this.btnUploadPhoto.UseVisualStyleBackColor = true;
            this.btnUploadPhoto.Click += new System.EventHandler(this.btnUploadPhoto_Click);

            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            this.openFileDialog.Title = "Select Player Photo";

            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 400);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.lblTeamName);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.lblBattingStyle);
            this.Controls.Add(this.lblBowlingStyle);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.txtPlayerName);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.txtRole);
            this.Controls.Add(this.txtBattingStyle);
            this.Controls.Add(this.txtBowlingStyle);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnUploadPhoto);
            this.Name = "Form2";
            this.Text = "Add New Player";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtPlayerName;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.TextBox txtBattingStyle;
        private System.Windows.Forms.TextBox txtBowlingStyle;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblBattingStyle;
        private System.Windows.Forms.Label lblBowlingStyle;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Button btnUploadPhoto;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}
