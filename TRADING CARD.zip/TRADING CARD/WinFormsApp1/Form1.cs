using System;
using System.Linq;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Drawing.Drawing2D;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.ClientSize = new Size(1200, 800);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Optional: Call the method to create the database when the form loads
            CreateDatabase();
            LoadPlayerNames();
        }

        private void CreateDatabase()
        {
            try
            {
                using (var context = new PlayerContext())
                {
                    if (!context.Database.Exists())
                    {
                        context.Database.Create();
                    }
                }

                // Optionally, create the Players table if not already created
                CreateTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void CreateTable()
        {
            try
            {
                using (var context = new PlayerContext())
                {
                    // Use LINQ to check if the table already exists
                    if (!context.Database.Exists())
                    {
                        context.Database.Create();
                    }

                    // Add default players if the table is empty
                    if (!context.Players.Any())
                    {
                        context.Players.Add(new Player
                        {
                            PlayerName = "Player1",
                            TeamName = "TeamA",
                            Role = "Batsman",
                            BattingStyle = "Right-hand",
                            BowlingStyle = "Right-arm fast",
                            DOB = new DateTime(1990, 5, 10),
                            PhotoPath = "path_to_photo1"
                        });
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void LoadPlayerNames()
        {
            try
            {
                using (var context = new PlayerContext())
                {
                    // Use LINQ to retrieve player names
                    var players = context.Players.Select(player => player.PlayerName).ToList();

                    // Clear previous controls
                    flowLayoutPanel1.Controls.Clear();

                    // Ensure vertical arrangement of LinkLabels
                    flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;

                    // Iterate over the players and add them to the FlowLayoutPanel
                    foreach (var playerName in players)
                    {
                        // Example usage
                        flowLayoutPanel1.Controls.Add(CreateStyledLinkLabel(playerName));

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Form1.cs
        private void DisplayPlayerCard(string playerName)
        {
            try
            {
                // Use LINQ to query the players from the context
                using (var context = new PlayerContext())
                {
                    var player = (from p in context.Players
                                  where p.PlayerName == playerName
                                  select p).FirstOrDefault();

                    if (player != null)
                    {
                        // Extract player details from the LINQ query result
                        string playerTeam = player.TeamName;
                        string playerRole = player.Role;
                        string battingStyle = player.BattingStyle;
                        string bowlingStyle = player.BowlingStyle;
                        DateTime dob = player.DOB;
                        string photoFileName = player.PhotoPath; // Assuming PhotoPath stores the file name (e.g., "player1.jpg")

                        string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                        // Navigate to the root directory of the project
                        string projectRootDirectory = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\.."));
                        //string imageFolderPath = Path.Combine(projectRootDirectory, "Images");
                        string imagePath = Path.Combine(projectRootDirectory, photoFileName); // Combine the folder path and file name

                        // Clear the existing controls from the player card panel
                        splitContainer1.Panel2.Controls.Clear();

                        // Create and add labels dynamically
                        Label nameLabel = new Label
                        {
                            Text = $"{playerName}",
                            AutoSize = true,
                            Font = new Font("Arial", 18, FontStyle.Bold),
                            Location = new Point(10, 10) // Initial location of the name label
                        };
                        splitContainer1.Panel2.Controls.Add(nameLabel);

                        PictureBox playerPhoto = new PictureBox
                        {
                            Image = Image.FromFile(imagePath), // Use the full path to the image
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            Size = new Size(200, 200),
                            Location = new Point(10, nameLabel.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(playerPhoto);

                        Label teamLabel = new Label
                        {
                            Text = $"Team: {playerTeam}",
                            AutoSize = true,
                            Font = new Font("Arial", 14, FontStyle.Regular),
                            Location = new Point(10, playerPhoto.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(teamLabel);

                        Label roleLabel = new Label
                        {
                            Text = $"Role: {playerRole}",
                            AutoSize = true,
                            Font = new Font("Arial", 14, FontStyle.Regular),
                            Location = new Point(10, teamLabel.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(roleLabel);

                        Label battingStyleLabel = new Label
                        {
                            Text = $"Batting Style: {battingStyle}",
                            AutoSize = true,
                            Font = new Font("Arial", 14, FontStyle.Regular),
                            Location = new Point(10, roleLabel.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(battingStyleLabel);

                        Label bowlingStyleLabel = new Label
                        {
                            Text = $"Bowling Style: {bowlingStyle}",
                            AutoSize = true,
                            Font = new Font("Arial", 14, FontStyle.Regular),
                            Location = new Point(10, battingStyleLabel.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(bowlingStyleLabel);

                        Label dobLabel = new Label
                        {
                            Text = $"DOB: {dob.ToShortDateString()}",
                            AutoSize = true,
                            Font = new Font("Arial", 14, FontStyle.Regular),
                            Location = new Point(10, bowlingStyleLabel.Bottom + 10)
                        };
                        splitContainer1.Panel2.Controls.Add(dobLabel);

                        // Modify button
                        Button modifyButton = new Button
                        {
                            Text = "Modify",
                            Size = new Size(120, 40),
                            Location = new Point(10, dobLabel.Bottom + 20),
                            Font = new Font("Arial", 12, FontStyle.Regular),
                            BackColor = Color.LightBlue
                        };
                        modifyButton.Click += (sender, e) =>
                        {
                            Form3 modifyForm = new Form3(playerName);
                            modifyForm.ShowDialog();
                            LoadPlayerNames();// Open the form as a dialog
                        };
                        splitContainer1.Panel2.Controls.Add(modifyButton);

                        // Delete button
                        Button deleteButton = new Button
                        {
                            Text = "Delete",
                            Size = new Size(120, 40),
                            Location = new Point(modifyButton.Right + 10, dobLabel.Bottom + 20),
                            Font = new Font("Arial", 12, FontStyle.Regular),
                            BackColor = Color.LightCoral
                        };
                        deleteButton.Click += (sender, e) =>
                        {
                            DialogResult result = MessageBox.Show($"Are you sure you want to delete {playerName}?", "Confirm Deletion", MessageBoxButtons.YesNo);
                            if (result == DialogResult.Yes)
                            {
                                using (var contextForDeletion = new PlayerContext())
                                {
                                    var playerToDelete = contextForDeletion.Players.FirstOrDefault(p => p.PlayerName == playerName);
                                    if (playerToDelete != null)
                                    {
                                        contextForDeletion.Players.Remove(playerToDelete);
                                        contextForDeletion.SaveChanges();
                                        MessageBox.Show($"{playerName} has been deleted successfully.");

                                        // Refresh the player names list after deletion
                                        LoadPlayerNames();

                                        // Optionally, clear the player details display
                                        splitContainer1.Panel2.Controls.Clear();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Player not found!");
                                    }
                                }
                            }
                        };
                        splitContainer1.Panel2.Controls.Add(deleteButton);
                    }
                    else
                    {
                        MessageBox.Show("Player not found!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private Panel CreateStyledLinkLabel(string playerName)
        {
            // Create a container panel to provide background and rounded corners
            Panel linkLabelPanel = new Panel
            {
                Width = flowLayoutPanel1.Width - 20, // Set the width to match the flow layout width (with some padding)
                Height = 40, // Set the height of the panel
                Padding = new Padding(5), // Padding for spacing inside the panel
                BackColor = Color.LightGray, // Background color for the panel
                Margin = new Padding(5), // Margin for spacing between items
            };

            // Apply rounded corners to the panel using the Paint event
            linkLabelPanel.Paint += (sender, e) =>
            {
                GraphicsPath path = new GraphicsPath();
                int cornerRadius = 10; // Set the corner radius
                path.AddArc(new Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90);
                path.AddArc(new Rectangle(linkLabelPanel.Width - cornerRadius - 1, 0, cornerRadius, cornerRadius), 270, 90);
                path.AddArc(new Rectangle(linkLabelPanel.Width - cornerRadius - 1, linkLabelPanel.Height - cornerRadius - 1, cornerRadius, cornerRadius), 0, 90);
                path.AddArc(new Rectangle(0, linkLabelPanel.Height - cornerRadius - 1, cornerRadius, cornerRadius), 90, 90);
                path.CloseFigure();

                // Fill the panel with light gray color and smooth the edges
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.FillPath(new SolidBrush(linkLabelPanel.BackColor), path); // Fill with background color
                e.Graphics.DrawPath(new Pen(Color.DarkGray), path); // Optional: Add a border
            };

            // Create the LinkLabel and add it to the Panel
            LinkLabel linkLabel = new LinkLabel
            {
                Text = playerName,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Regular),
                LinkColor = Color.Blue, // Set the link color
                ActiveLinkColor = Color.DarkBlue, // Set active link color
                VisitedLinkColor = Color.DarkCyan, // Set visited link color
                LinkBehavior = LinkBehavior.NeverUnderline, // Remove the underline
                TextAlign = ContentAlignment.MiddleLeft, // Align text to the left
                Padding = new Padding(5), // Padding for spacing inside the link label
            };

            // Add the LinkLabel to the Panel
            linkLabelPanel.Controls.Add(linkLabel);

            // Optional: Add event handler for clicking the link
            linkLabel.LinkClicked += (sender, e) =>
            {
                DisplayPlayerCard(playerName); // Handle the link click
            };

            return linkLabelPanel; // Return the entire panel with the LinkLabel
        }


    }
}
