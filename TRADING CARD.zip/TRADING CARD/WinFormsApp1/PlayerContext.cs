﻿using System.Data.Entity;

public class PlayerContext : DbContext
{
    public DbSet<Player> Players { get; set; }

    // Ensure connection string is correctly configured in app.config or OnConfiguring in case of EF Core
    public PlayerContext() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=MyLocalDatabase;Integrated Security=True")
    { }
}
