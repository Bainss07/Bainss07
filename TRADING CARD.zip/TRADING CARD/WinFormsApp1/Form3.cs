﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        private string playerName; // Store the player name
        public event Action PlayerModified;
        public Form3(string playerName)
        {
            InitializeComponent();
            this.playerName = playerName;
            LoadPlayerDetails(playerName);
        }

        private void LoadPlayerDetails(string playerName)
        {
            try
            {
                using (var context = new PlayerContext())
                {
                    var player = context.Players.FirstOrDefault(p => p.PlayerName == playerName);
                    if (player != null)
                    {
                        // Populate controls with player data
                        txtPlayerName.Text = player.PlayerName;
                        txtTeamName.Text = player.TeamName;
                        txtRole.Text = player.Role;
                        txtBattingStyle.Text = player.BattingStyle;
                        txtBowlingStyle.Text = player.BowlingStyle;
                        dtpDOB.Value = player.DOB;

                        // Load player photo (ensure path is correct)
                        string photoPath = player.PhotoPath;
                        if (!string.IsNullOrEmpty(photoPath))
                        {


                            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                            // Navigate to the root directory of the project
                            string projectRootDirectory = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\.."));
                            string imageFolderPath = Path.Combine(projectRootDirectory, "Images");



                            // Construct the full absolute path for the image
                            string imagesDirectory = projectRootDirectory; // Absolute path
                            string fullPath = System.IO.Path.Combine(imagesDirectory, photoPath);


                            MessageBox.Show($"Loading image from: {fullPath}"); // Debugging the path

                            try
                            {
                                // Check if the file exists before attempting to load it
                                if (System.IO.File.Exists(fullPath))
                                {
                                    // Use FileStream to load the image
                                    using (var stream = new System.IO.FileStream(fullPath, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                                    {
                                        pictureBoxPlayer.Image = Image.FromStream(stream);
                                        pictureBoxPlayer.SizeMode = PictureBoxSizeMode.StretchImage; // Ensure proper sizing
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Image file not found!");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error loading image: {ex.Message}");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Player has no image path stored.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Player not found!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new PlayerContext())
                {
                    var player = context.Players.FirstOrDefault(p => p.PlayerName == playerName);
                    if (player != null)
                    {
                        // Update player details from controls
                        player.PlayerName = txtPlayerName.Text;
                        player.TeamName = txtTeamName.Text;
                        player.Role = txtRole.Text;
                        player.BattingStyle = txtBattingStyle.Text;
                        player.BowlingStyle = txtBowlingStyle.Text;
                        player.DOB = dtpDOB.Value;

                        // Optionally, update photo
                        if (pictureBoxPlayer.Image != null)
                        {
                            // Save the image to the Images folder
                            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                            string projectRootDirectory = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\.."));
                            string imageFolderPath = Path.Combine(projectRootDirectory, "Images");

                            // Ensure the Images directory exists
                            if (!Directory.Exists(imageFolderPath))
                            {
                                Directory.CreateDirectory(imageFolderPath);
                            }

                            // Generate a unique GUID for the image file name
                            string uniqueId = Guid.NewGuid().ToString();
                            string fileExtension = GetImageExtension(pictureBoxPlayer.Image.RawFormat);
                            if (string.IsNullOrEmpty(fileExtension))
                            {
                                MessageBox.Show("Unsupported image format.");
                                return;
                            }

                            string photoFileName = $"{txtPlayerName.Text}_{uniqueId}{fileExtension}";
                            string photoFullPath = Path.Combine(imageFolderPath, photoFileName);

                            // Save image using MemoryStream
                            using (var memoryStream = new MemoryStream())
                            {
                                pictureBoxPlayer.Image.Save(memoryStream, pictureBoxPlayer.Image.RawFormat);
                                File.WriteAllBytes(photoFullPath, memoryStream.ToArray());
                            }

                            // Save the relative path to the database
                            player.PhotoPath = Path.Combine("Images", photoFileName).Replace("\\", "/");
                        }

                        context.SaveChanges();
                        MessageBox.Show("Player details updated successfully.");

                        // Trigger the event to notify Form1
                        PlayerModified?.Invoke();

                        this.Close(); // Close the form after saving
                    }
                    else
                    {
                        MessageBox.Show("Player not found!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Helper function to get the file extension from the image format
        private string GetImageExtension(System.Drawing.Imaging.ImageFormat format)
        {
            if (format.Equals(System.Drawing.Imaging.ImageFormat.Jpeg)) return ".jpg";
            if (format.Equals(System.Drawing.Imaging.ImageFormat.Png)) return ".png";
            if (format.Equals(System.Drawing.Imaging.ImageFormat.Bmp)) return ".bmp";
            if (format.Equals(System.Drawing.Imaging.ImageFormat.Gif)) return ".gif";
            return string.Empty; // Unsupported format
        }

        private void btnChangePhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBoxPlayer.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
    }
}
